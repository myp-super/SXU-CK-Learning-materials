library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity sipo_loop is
    Port ( clk  : in  STD_LOGIC;
           rst  : in  STD_LOGIC;
           din  : in  STD_LOGIC; -- 串行输入
           dout : out STD_LOGIC_VECTOR (3 downto 0)); -- 并行输出
end sipo_loop;

architecture Behavioral of sipo_loop is
    signal q_reg : STD_LOGIC_VECTOR(3 downto 0);
begin
    process(clk, rst)
    begin
        if rst = '1' then
            q_reg <= "0000";
        elsif rising_edge(clk) then
            -- 使用for loop实现数据移位
            for i in 3 downto 1 loop
                q_reg(i) <= q_reg(i-1);
            end loop;
            q_reg(0) <= din; -- 新数据从最低位移入
        end if;
    end process;
    dout <= q_reg;
end Behavioral;