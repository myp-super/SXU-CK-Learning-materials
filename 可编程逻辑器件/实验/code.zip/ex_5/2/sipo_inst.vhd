library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- 改名 dff_rst，不和Quartus内置dff重名
entity dff_rst is
    Port ( d   : in  STD_LOGIC;
           clk : in  STD_LOGIC;
           rst : in  STD_LOGIC;
           q   : out STD_LOGIC);
end dff_rst;

architecture Behavioral of dff_rst is
begin
    process(clk, rst)
    begin
        if rst = '1' then
            q <= '0';
        elsif rising_edge(clk) then
            q <= d;
        end if;
    end process;
end Behavioral;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity sipo_inst is
    Port ( clk  : in  STD_LOGIC;
           rst  : in  STD_LOGIC;
           din  : in  STD_LOGIC;
           dout : out STD_LOGIC_VECTOR(3 downto 0));
end sipo_inst;

architecture Structural of sipo_inst is
    -- 组件同步改名 dff_rst
    component dff_rst
        Port ( d, clk, rst : in STD_LOGIC; q : out STD_LOGIC);
    end component;
    signal q_int : STD_LOGIC_VECTOR(3 downto 0);
begin
    U0: dff_rst port map(d => din,      clk => clk, rst => rst, q => q_int(0));
    U1: dff_rst port map(d => q_int(0), clk => clk, rst => rst, q => q_int(1));
    U2: dff_rst port map(d => q_int(1), clk => clk, rst => rst, q => q_int(2));
    U3: dff_rst port map(d => q_int(2), clk => clk, rst => rst, q => q_int(3));
    
    dout <= q_int;
end Structural;