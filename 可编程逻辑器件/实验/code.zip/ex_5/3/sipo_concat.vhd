library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity sipo_concat is
    Port ( clk  : in  STD_LOGIC;
           rst  : in  STD_LOGIC;
           din  : in  STD_LOGIC;
           dout : out STD_LOGIC_VECTOR (3 downto 0));
end sipo_concat;

architecture Behavioral of sipo_concat is
    signal q_reg : STD_LOGIC_VECTOR(3 downto 0);
begin
    process(clk, rst)
    begin
        if rst = '1' then
            q_reg <= "0000";
        elsif rising_edge(clk) then
            -- 并置符实现移位：保留低3位并左移，din补在最低位
            q_reg <= q_reg(2 downto 0) & din; 
        end if;
    end process;
    dout <= q_reg;
end Behavioral;