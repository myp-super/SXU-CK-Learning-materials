library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MUX41 is
    Port ( D : in  STD_LOGIC_VECTOR (3 downto 0); -- 4路数据输入
           S : in  STD_LOGIC_VECTOR (1 downto 0); -- 2路选择控制输入
           Y : out STD_LOGIC);                    -- 1路数据输出
end MUX41;

architecture Behavioral of MUX41 is
begin
    process(D, S)
    begin
        -- 使用 case 语句实现数据选择逻辑
        case S is
            when "00" => 
                Y <= D(0);
            when "01" => 
                Y <= D(1);
            when "10" => 
                Y <= D(2);
            when "11" => 
                Y <= D(3);
            when others => 
                Y <= '0'; -- 养成良好习惯，处理 others 分支防止生成锁存器
        end case;
    end process;
end Behavioral;