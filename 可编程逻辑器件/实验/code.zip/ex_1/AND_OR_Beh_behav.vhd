--行为描述
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity AND_OR_Beh is
    Port ( A : in  STD_LOGIC;
           B : in  STD_LOGIC;
           C : in  STD_LOGIC;
           D : in  STD_LOGIC;
           Y : out STD_LOGIC);
end AND_OR_Beh;

architecture Behavioral of AND_OR_Beh is
begin
    process(A, B, C, D)
    begin
        if ((A = '1' and B = '1') or (C = '1' and D = '1')) then
            Y <= '1';
        else
            Y <= '0';
        end if;
    end process;
end Behavioral;