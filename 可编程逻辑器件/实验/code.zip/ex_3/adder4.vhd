library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity full_adder is
    Port ( a : in STD_LOGIC;
           b : in STD_LOGIC;
           cin : in STD_LOGIC;
           sum : out STD_LOGIC;
           cout : out STD_LOGIC);
end full_adder;

architecture Behavioral of full_adder is
begin
    -- 1位全加器的逻辑表达
    sum <= a xor b xor cin;
    cout <= (a and b) or (cin and (a xor b));
end Behavioral;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity adder4 is
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           Cin : in STD_LOGIC;
           Sum : out STD_LOGIC_VECTOR (3 downto 0);
           Cout : out STD_LOGIC);
end adder4;

architecture Structural of adder4 is
    -- 声明底层全加器组件
    component full_adder
        Port ( a, b, cin : in STD_LOGIC;
               sum, cout : out STD_LOGIC);
    end component;
    
    -- 声明内部进位信号线，C(0)接Cin，C(4)接Cout
    signal C : STD_LOGIC_VECTOR (4 downto 0);
begin
    C(0) <= Cin;
    
    -- 手动进行4次元件例化（级联）
    U0: full_adder port map(a => A(0), b => B(0), cin => C(0), sum => Sum(0), cout => C(1));
    U1: full_adder port map(a => A(1), b => B(1), cin => C(1), sum => Sum(1), cout => C(2));
    U2: full_adder port map(a => A(2), b => B(2), cin => C(2), sum => Sum(2), cout => C(3));
    U3: full_adder port map(a => A(3), b => B(3), cin => C(3), sum => Sum(3), cout => C(4));
    
    Cout <= C(4);
end Structural;