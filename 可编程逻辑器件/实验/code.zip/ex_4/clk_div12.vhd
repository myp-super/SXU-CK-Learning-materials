library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL; -- 引入无符号数加法与比较库

entity clk_div12 is
    Port ( clk     : in  STD_LOGIC;                    -- 输入时钟信号
           rst     : in  STD_LOGIC;                    -- 异步复位信号，高电平有效
           cnt_out : out STD_LOGIC_VECTOR(3 downto 0); -- 4位当前状态输出
           clk_out : out STD_LOGIC);                   -- 分频脉冲输出
end clk_div12;

architecture Behavioral of clk_div12 is
    signal count : STD_LOGIC_VECTOR(3 downto 0) := "0000";
begin
    process(clk, rst)
    begin
        if rst = '1' then
            count <= "0000";
            clk_out <= '0';
        elsif rising_edge(clk) then
            -- 根据状态表，当计数到S11("1011")时，下一个状态清零并输出高电平脉冲
            if count = "1011" then
                count <= "0000";
                clk_out <= '1';
            else
                count <= count + 1;
                clk_out <= '0';
            end if;
        end if;
    end process;

    cnt_out <= count; -- 将内部计数状态引出，便于观察状态表
end Behavioral;