library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity seq_det_moore is
    Port ( clk  : in  STD_LOGIC;
           rst  : in  STD_LOGIC;
           din  : in  STD_LOGIC;
           dout : out STD_LOGIC);
end seq_det_moore;

architecture Behavioral of seq_det_moore is
    -- Moore型需要5个状态
    type state_type is (S0, S1, S2, S3, S4);
    signal current_state, next_state : state_type;
begin
    process(clk, rst)
    begin
        if rst = '1' then
            current_state <= S0;
        elsif rising_edge(clk) then
            current_state <= next_state;
        end if;
    end process;

    process(current_state, din)
    begin
        -- 默认赋值
        next_state <= current_state; 
        
        case current_state is
            when S0 => -- 初始状态
                if din = '1' then next_state <= S1; else next_state <= S0; end if;
            when S1 => -- 检测到 "1"
                if din = '1' then next_state <= S2; else next_state <= S0; end if;
            when S2 => -- 检测到 "11"
                if din = '0' then next_state <= S3; else next_state <= S2; end if;
            when S3 => -- 检测到 "110"
                if din = '1' then next_state <= S4; else next_state <= S0; end if;
            when S4 => -- 检测到完整的 "1101"
                if din = '1' then 
                    next_state <= S2; -- 如果继续输入1，相当于"11011"，匹配了前缀"11"，跳至S2
                else 
                    next_state <= S0; 
                end if;
            when others =>
                next_state <= S0;
        end case;
    end process;
    
    -- Moore型的输出仅依靠当前状态
    dout <= '1' when current_state = S4 else '0';

end Behavioral;