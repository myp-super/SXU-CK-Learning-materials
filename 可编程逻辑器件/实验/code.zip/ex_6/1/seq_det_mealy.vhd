library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity seq_det_mealy is
    Port ( clk  : in  STD_LOGIC;
           rst  : in  STD_LOGIC;
           din  : in  STD_LOGIC;
           dout : out STD_LOGIC);
end seq_det_mealy;

architecture Behavioral of seq_det_mealy is
    -- Mealy型仅需4个状态来检测4位序列
    type state_type is (S0, S1, S2, S3);
    signal current_state, next_state : state_type;
begin
    -- 进程1：同步状态更新
    process(clk, rst)
    begin
        if rst = '1' then
            current_state <= S0;
        elsif rising_edge(clk) then
            current_state <= next_state;
        end if;
    end process;

    -- 进程2：组合逻辑判定次态与输出
    process(current_state, din)
    begin
        -- 默认输出为0，防止锁存器
        dout <= '0'; 
        case current_state is
            when S0 => -- 初始状态
                if din = '1' then next_state <= S1; else next_state <= S0; end if;
            when S1 => -- 检测到 "1"
                if din = '1' then next_state <= S2; else next_state <= S0; end if;
            when S2 => -- 检测到 "11"
                if din = '0' then next_state <= S3; else next_state <= S2; end if;
            when S3 => -- 检测到 "110"
                if din = '1' then 
                    dout <= '1'; -- Mealy型在S3且输入为1时直接输出高电平
                    next_state <= S1; -- 可重叠检测：最后的'1'作为下一个序列的开始
                else 
                    next_state <= S0; 
                end if;
            when others =>
                next_state <= S0;
        end case;
    end process;
end Behavioral;